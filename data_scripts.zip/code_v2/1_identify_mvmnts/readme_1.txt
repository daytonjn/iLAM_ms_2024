scripts with species/experiment/cage-specific settings to process iLAM-captured images and identify all movements

input: image files (not included here)
output: CSV with movements, size, coordinate location, and time for each iLAM (located in ./output/)

